﻿15pack 112ride is a game akin to the mobile game Jetpack Joyride. In the game, the player uses their jetpack to dodge a number of obstacles, collecting coins on the way. The obstacles are randomly generated based on the speed of the current game. The player can click a certain button to see a possible path for the player for the current instance of the game.


To run the project, the user should download the .py file in the zip file, as well as the provided images. 


No external libraries are being used.


Pressing ‘p’ pauses the game. Pressing ‘o’ moves the game one step forward while the game is paused. Pressing ‘l’ shows a possible path for the player to go.